let txt = document.getElementByID('text');
function servers(){
    txt.innerHTML = "Server was clicked.";
};
document.onclick = document.write('test');